
from django.shortcuts import render
from django.http import HttpResponse
import nltk
from nltk import word_tokenize, pos_tag
import django
import cgi
from django.http import HttpResponseRedirect
from django.shortcuts import render

from .forms import TextForm

# Create your views here.
def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")

def Literary_Value(sentence):
	words_tag = pos_tag(word_tokenize(sentence))
	score = 0
	for i in words_tag:
		#noun
		if 'NN'in i[1]:
			score += 7   
		#verb
		if 'VB'in i[1]:
			score += 14
		#adverb
		if 'ADV'in i[1]:
			score -= 21
		#adjective
		if 'ADJ'in i[1]:
			score *= 2

	return score	

def Literary_Value_as_output(sentence):

	if request.method == 'POST':
		sentence = TextForm(request.POST)
		if form.is_valid():
				
			words_tag = pos_tag(word_tokenize(sentence))
			score = 0
			for i in words_tag:
				#noun
				if 'NN'in i[1]:
					score += 7   
				#verb
				if 'VB'in i[1]:
					score += 14
				#adverb
				if 'ADV'in i[1]:
					score -= 21
				#adjective
				if 'ADJ'in i[1]:
					score *= 2

			return HttpResponseRedirect('/'+ score +'/')
	else:
        	form = TextForm()
	sentence = input("Enter your text: ") 
	print(Literary_Value(sentence)) 
    	return render(request, 'text.html', {'form': form})




