from django import forms

class TextForm(forms.Form):
    your_name = forms.CharField(label='Your text')
